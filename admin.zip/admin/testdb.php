<?php
include("DbConfig.php");
/*
$servername = "localhost";
$username = "sk_user";
$password = "at=MCT}mr%ov";
$dbname="skillpundityelm";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
echo "Connected successfully";
*/
echo $sql="update contests_add set prize_amount=10000 where id=16";
$sqlres=$obj_db->get_qresult($sql);
?>