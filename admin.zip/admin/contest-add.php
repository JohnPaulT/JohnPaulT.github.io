<?php
include("DbConfig.php");
   if(isset($_POST["submit"]))
   {
      $startdate = date("Y-m-d", strtotime($_POST["Start_Date"]));
                                $enddate = date("Y-m-d", strtotime($_POST["End_Date"]));
      $sql="insert into contests_add set contest_name='".$_POST["Contest_Name"]."',category='".$_POST["Category"]."',prize_amount='".$_POST["Prize_Amount"]."',start_date='".$startdate."',end_date='".$enddate."',status='".$_POST["name"]."',  audio_file='".$_POST["audio"]."',description='".$_POST["description"]."',video_file='".$_POST["video_file"]."',time_duration='".$_POST["Time_Duration"]."'";
         $sqlres=$obj_db->get_qresult($sql);
         
        $new_file_name=$_FILES['audio']['name'];
        $target_path = "audiofiles/".$new_file_name;
 
 
if(move_uploaded_file($_FILES['audio']['tmp_name'],"audiofiles/".$new_file_name)){

  $sql1="select * from contests_add";
$sqlres1=$obj_db->get_qresult($sql1);
$last=$obj_db->insert_id($sql1);
 $sql2="update contests_add set audio_file='$last-".$new_file_name."' where id='".$last."'";
   $sqlres2=$obj_db->get_qresult($sql2);
}

header("Location:contests.php");
}
if(isset($_POST["audio"]))

{

$sql3 = "select * from contests_add";

$sqlres3=$obj_db->get_qresult($sql3);

  while($row3=$obj_db->fetchArray($sqlres3))

  {
  //print_r($row);
?>
   
 
  
  
  <?php } 
   }
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
<!-- DATE PICKER STYLE  -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <form action="" method="POST" enctype="multipart/form-data">
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contest Add</h4><a href="contests.php" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                        <div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form role="form">
                                    <div class="form-group">
                                        <label class="colm">Category<span>:</span></label><span class="col-sm-8">

                                            <select class="form-control" class="form-control" name="Category">
                              

                              <option value="">Select </option>

                              <?php
                                include("DbConfig.php");

                              $sql="select * from category";
                              $sqlres=$obj_db->get_qresult($sql);
                              while($rows=$obj_db->fetchArray($sqlres))
                              {
                                 ?>
                            <option value="<?php echo $rows["c_id"];?>"><?php echo $rows["category"];?></option>
                              
                               <?php

                                  }
                                  ?>
                    
                            </select></span>
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Title<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Contest_Name"/></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Description<span>:</span></label><span class="col-sm-8"><textarea name="description">Next, use our Get Started docs to setup Tiny!</textarea></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Audio File<span>:</span></label><span class="col-sm-8">
                                            <input name="audio" id="audio" type="file" value="<?php echo $_POST["audio"];?> "  />
                                        </span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Video File(Embedded Code)<span>:</span></label><span class="col-sm-8">
                                            <input type="text" class="form-control" name="video_file" value="<?php echo $_POST["video_file"];?> "/> 
                                        </span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Status<span>:</span></label><span class="col-sm-8">
                                             Active <input type="radio" value="Active" name="name">
                                             Inactive <input type="radio" value="Inactive" name="name">
                                        </span>                                        
                                    </div>



                                    <div class="form-group">
                                        <label class="colm">Start Date<span>:</span></label><span class="col-sm-8"><div id="datepicker1" class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text"  id="datepicker1" name="Start_Date"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">End Date<span>:</span></label><span class="col-sm-8"><div id="datepicker2" class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text" name="End_Date" id="datepicker2"  />
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Time Duration<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Time_Duration"/></span>                                        
                                    </div>
                                    
                                    
                                    
                                    <div class="form-group">
                                        <label class="colm">Prize Amount<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Prize_Amount"/></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm"></label><span class="col-sm-4">


                                            <input type="submit" value="Submit" name="submit" class="btn btn-success">
                                                                                   
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- TINYMCE SCRIPTS  -->
    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
    <!-- DATE PICKER SCRIPTS  -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
    <script>
    $(function () {
      $("#datepicker1").datepicker({ 
            autoclose: true, 
            format: 'dd-mm-yyyy',
            todayHighlight: true
      });
      
      
      $("#datepicker2").datepicker({ 
            autoclose: true, 
            format: 'dd-mm-yyyy',
            todayHighlight: true
      });
    
    });
    </script>
    </form>
</body>
</html>