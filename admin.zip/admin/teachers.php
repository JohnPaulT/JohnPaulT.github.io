<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- DATA TABLES STYLE  -->
<link href="assets/css/dataTables.bootstrap.min.css" rel="stylesheet" />
</head>

<body>
    
    <!-- LOGO HEADER END-->
   
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Teachers</h4>
                </div>
            </div>            
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover data-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>First Name</th>
                                            <th>Last Name</th>
                                            <th>Father Name</th>
                                            <th>Phone Number</th>
                                            <th>Email ID</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Teste</td>
                                            <td>Tester</td>
                                            <td>Test-tester</td>
                                            <td>9876543210</td>
                                            <td>test@test@gmail.com</td>
                                            <td class="action"><a href="teacher-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="teacher-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                            </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Test</td>
                                            <td>Tester</td>
                                            <td>Test1-tester</td>
                                            <td>94987653210</td>
                                            <td>test@test@gmail.com</td>
                                            <td class="action"><a href="teacher-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="teacher-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Test2</td>
                                            <td>Tester2</td>
                                            <td>Test2-tester</td>
                                            <td>9896543210</td>
                                            <td>test1@test@gmail.com</td>
                                            <td class="action"><a href="teacher-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="teacher-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>Test3</td>
                                            <td>Tester3</td>
                                            <td>Test3-tester</td>
                                            <td>9890632104</td>
                                            <td>test@test@gmail.com</td>
                                            <td class="action"><a href="teacher-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="teacher-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                       </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>Test4</td>
                                            <td>Tester4</td>
                                            <td>Test4-tester</td>
                                            <td>99987653210</td>
                                            <td>test4@test@gmail.com</td>
                                            <td class="action"><a href="teacher-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="teacher-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATA TABLES SCRIPTS  -->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.min.js"></script>
    <script>
		$(document).ready(function() {
		$('#example').DataTable();
	} );
	</script>
</body>
</html>