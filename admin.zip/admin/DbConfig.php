<?php



/// database mysql functions







// if db class not exists



//error_reporting(0);



//error_reporting(E_ALL);



//ini_set("display_errors", 0);



$debug = isset($_GET['debug'])?(int)$_GET['debug']:0;

//if($_SERVER['REMOTE_ADDR']=='117.203.97.115') $debug=1;

if($debug) {

	error_reporting(E_ALL);

	ini_set("display_errors", 1);

} else {

	error_reporting(0); 

	ini_set("display_errors", 0); 

}


if(!class_exists("db")) {







	class db 







	{ // class starting     







		public $dbconnect;







		 //Mysql connection start







		 public function open_connection()







		 {

        	$hostname = "localhost";



					
 


					$username = "sk_user";

					$password = "at=MCT}mr%ov";


					$database = "skillpundityelm";


					$this->dbconnect = mysqli_connect($hostname,$username,$password,$database);





		 }



		 //Mysql connection close







		 public function close_connection()







		 {

	
				mysqli_close($this->dbconnect);

		 }
	//Multiple rows fetching


		function fetchArray($query_result){		
		$array = mysqli_fetch_assoc($query_result);

			return $array;

		}


		//Get query result

		function get_qresult($get_query){

			$get_result = mysqli_query($this->dbconnect,$get_query);

			return $get_result;



		}

		//getting single record


		function fetchRow($select_query){

	     $select_result=mysqli_query($this->dbconnect,$select_query);



			$select_row = mysqli_fetch_assoc($select_result);

			return $select_row;


		}	

		//getting selected field in a record







		function fetch_field($select_query){


			$select_result=mysqli_query($this->dbconnect,$select_query);



			$select_row = mysqli_fetch_row($select_result);


			if($select_row) return $select_row[0]; else return 0;







		}	


		//count records







		function fetchNum($select_query){







			$select_result=mysqli_query($this->dbconnect,$select_query);



			$get_num = mysqli_num_rows($select_result);







			return $get_num;







		}



		//record last insert id



		function insert_id(){			



			return mysqli_insert_id($this->dbconnect);



		}







	} // class ending



	



	$pb=array(0=>100, 1=>60, 2=>40, 3=>30, 4=>25, 5=>20, 6=>17, 7=>15, 8=>13, 10=>12);



	// database tables







define('TABLE_REG_USERS','kg_reg_users');
define('TABLE_POST_REG_USERS','job_post_users');
define('TABLE_ADMINISTRATOR','kg_admin');
define('TABLE_Qualification','kg_qualification');
define('TABLE_JOBS','jp_jobs');
define('TABLE_PANCHAYAT','grampanchayat');
define('TABLE_MANDAL','mandal');
define('TABLE_CATEGORY','category');










	$obj_db = new db();



	$obj_db->open_connection();



	



	define('CHART_TIME',48*60*60);

 
//ini_set("session.gc_maxlifetime", "60");
date_default_timezone_set('Asia/Kolkata');

if(!function_exists("redirect_url1")) {
		function redirect_url1($page){
			header("location: ".$page);
			exit;
		}
	}



}	
?>