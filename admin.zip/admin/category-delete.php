<?php
session_start();
include("DbConfig.php");
$sql="delete from category where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);

header("Location:category.php");

?>