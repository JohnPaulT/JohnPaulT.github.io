<?php
session_start();
include("DbConfig.php");
if(!isset($_SESSION["username"]))
{
    header('Location:login.php');
    exit();
    
    
}
if(isset($_POST["submit"]))
{
    $sql="insert into category set category='".$_POST["category_name"]."'";
    $sqlres=$obj_db->get_qresult($sql);
    $last=$obj_db->insert_id($sql);
    
    $sql1="select * from category where id='".$last."'";
    $sqlres1=$obj_db->get_qresult($sql1);
    $row1=$obj_db->fetchRow($sql1);
    
    $sql2="update category set c_id='s".$row1["id"]."' where id='".$last."'";
    
    $sqlres2=$obj_db->get_qresult($sql2);
    
header("Location:category.php");
}

?>






<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Category Add</h4><a href="category.php" class="btn btn-success">back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form action="" method="POST">
                                	<div class="form-group">
                                    	<label class="colm">Category Name<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" name="category_name"/></span>
                                    </div>
                                	<div class="form-group">
                                    	<label class="colm"></label><span class="col-sm-4">
                                    	    <input type="submit" name="submit" value="submit" class="btn btn-success"
                                    	    
                                    	    </span>
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</body>
</html>