
<?php
session_start();
include("DbConfig.php");
if(!isset($_SESSION["username"]))
{
    header('Location:login.php');
    exit();
    
    
}



 

                              if(isset($_POST["submit"]))
                              {

                                $startdate = date("Y-m-d", strtotime($_POST["Start_Date"]));
                                $enddate = date("Y-m-d", strtotime($_POST["End_Date"]));

                                $sql2="update contests_add set contest_name='".$_POST["Contest_Name"]."',category='".$_POST["Category"]."',prize_amount='".$_POST["Prize_Amount"]."',start_date='".$startdate."',end_date='".$enddate."',status='".$_POST["status"]."',description='".$_POST["description"]."',time_duration='".$_POST["Time_Duration"]."',video_file='".$_POST["video_file"]."' where id='".$_GET["id"]."'";
                                  
                                $sqlres2=$obj_db->get_qresult($sql2);

                                 
                                 $new_file_name=$_FILES['audio']['name'];
                                 $target_path = "audiofiles/".$new_file_name;
 
 
                            if(move_uploaded_file($_FILES['audio']['tmp_name'],"audiofiles/".$new_file_name))

                            {

                              echo $sql3="update contests_add set audio_file='$last-".$new_file_name."' where id='".$_GET["id"]."'";
                             
                                    $sqlres3=$obj_db->get_qresult($sql3);
                                     
                                    
                               }

                             
                                header('Location:contests.php');
                                     
                              }
                                
                              


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
<!-- DATE PICKER STYLE  -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/css/datepicker.css" rel="stylesheet" type="text/css" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
 

    
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
         <form action="" method="POST" enctype="multipart/form-data">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contest Edit</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                      <div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                               <?php
                            $sql="select * from contests_add where id='".$_GET["id"]."'";
                            $sqlres=$obj_db->get_qresult($sql);
                                   while(
                                    $rows1=$obj_db->fetchArray($sqlres))

                                           {
                                           ?>
                                  <div class="form-group">
                                      <label class="colm">Title<span>:</span></label><span class="col-sm-8"><input type="text" name="Contest_Name"class="form-control" value="<?php echo $rows1["contest_name"];?>" /></span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Category<span>:</span></label><span class="col-sm-8">

                                            <select class="form-control" class="form-control" name="Category">
                              

                              <option value="">Select </option>

                              <?php
                               

                              $sql="select * from category";
                              $sqlres=$obj_db->get_qresult($sql);
                              while($rows=$obj_db->fetchArray($sqlres))
                              {
                                 ?>
                            <option value="<?php echo $rows["c_id"];?>" <?php if($rows1["category"]==$rows["c_id"]) echo "selected='selected'";?>><?php echo $rows["category"];?></option>
                              
                               <?php

                                  }
                                  ?>
                    
                            </select></span>
                                    </div>


                                  <div class="form-group">
                                      <label class="colm">Description<span>:</span></label><span class="col-sm-8"><textarea name="description"><?php echo $rows1["description"];?></textarea></span>                                        
                                    </div>
                                  <div class="form-group">
                                        <label class="colm">Start Date<span>:</span></label><span class="col-sm-8"><div 
                                        class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text"  name="Start_Date"  id="date1" value="<?php if($rows1["start_date"]!='0000-00-00') { echo $newDate = date("d-m-Y", strtotime($rows1["start_date"]));} ?>"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                   

                           </div>
                                    <div class="form-group">
                                        <label class="colm">End Date<span>:</span></label><span class="col-sm-8"><div  
                                        class="input-group date" data-date-format="dd/mm/yyyy">
    

    <input class="form-control" type="text"  name="End_Date"  id="date2" value="<?php if($rows1["end_date"]!='0000-00-00') { echo $newDate = date("d-m-Y", strtotime($rows1["end_date"]));} ?>"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>

                                    <div class="form-group">
                                      <label class="colm">Time Duration<span>:</span></label><span class="col-sm-8">

                                        <input type="text" name="Time_Duration" class="form-control" value="<?php echo $rows1["time_duration"];?>" />

                                        </span>                                        
                                    </div>
                                  <div class="form-group">
                                      <label class="colm">Price Amount<span>:</span></label><span class="col-sm-8"><input type="text" name="Prize_Amount" class="form-control" value="<?php echo $rows1["prize_amount"];?>" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                      <label class="colm">Audio File<span>:</span></label><span class="col-sm-8"> 

                                       <input name="audio" id="audio" type="file" value="<?php echo $_POST["audio"];?> "  />

                                       <audio controls>
                                                          <source src='audiofiles/<?php
                                                          $exp=explode('-',$rows1["audio_file"]);
                                             
                                             echo $exp[1];
                                                          
                                                          ?>' type='audio/mp3'>
  
                                                                </audio></span>                                        
                                    </div>



                                    
                                         <div class="form-group">
                                      <label class="colm">Video File<span>:</span></label><span class="col-sm-4">
                                        <input type="text" name="video_file" class="form-control" value="<?php echo $rows1["video_file"];?>" />
                                        
                                       <iframe width="560" height="315" src='<?php echo $rows1["video_file"];?>' frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                      </span>                                    </div>


                                    <div class="form-group">
                                      <label class="colm">Status<span>:</span></label><span class="col-sm-8"> <input name="status" type="radio" id="signi" value="Active" <?php echo ($rows1["status"]== 'Active') ?  "checked" : "" ;  ?>/>Active
<input name="status" type="radio" id="signi" value="Inactive" <?php echo ($rows1["status"]== 'Inactive') ?  "checked" : "" ;  ?>/>Inactive</span>                                        
                                    </div>
                           
                            
 <?php
                             
                                      }
                               ?> 
                              
                            
                                  <div class="form-group">
                                      <label class="colm"></label><span class="col-sm-8">
                                          
                                          <input type="submit" value="submit" name="submit" class="btn btn-success">
                                      </span>                                        
                                    </div>
                                

                               
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- TINYMCE SCRIPTS  -->
    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
    <!-- DATE PICKER SCRIPTS  -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
    <script>
    $(function() {
        
      $("#date1").datepicker({ 
            autoclose: true, 
            format: 'dd-mm-yyyy',
            todayHighlight: true
      });
    
    
       $("#date2").datepicker({ 
            autoclose: true, 
             format: 'dd-mm-yyyy',
            todayHighlight: true
      });
     
  
    
    });
    </script>
    
     
</body>
</html>