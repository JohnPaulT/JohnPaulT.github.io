
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- DATA TABLES STYLE  -->
<link href="assets/css/dataTables.bootstrap.min.css" rel="stylesheet" />
</head>

<body>
    
    
     <?php if($action == "edit") {?>
     
              <div class="content-wrapper">
      
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Category Edit</h4><a href="index.php?p=categories" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div> 
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form action="" method="POST">
                                     <?php
        include("DbConfig.php");
        $sql="select * from category where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);
$row=$obj_db->fetchRow($sql);

?>
                                	<div class="form-group">
                                    	<label class="colm">Category Name<span>:</span></label><span class="col-sm-4"><input type="text" name="category" class="form-control" value="<?php echo $row["category"];?>" /></span>
                                    </div>
                                    
                                	<div class="form-group">
                                    	<label class="colm"></label><span class="col-sm-4"></span>
                                    	  <input type="submit" name="btn_press_save" value="submit" class="btn btn-success">
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
     }
      if($action == "view") {  ?>
      
     
       <div class="content-wrapper">
         <?php
   
    $sql="select * from category where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);
$row=$obj_db->fetchRow($sql);
?>
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Category View</h4><a href="index.php?p=categories" class="btn btn-success">back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form>
                                	<div class="form-group">
                                    	<label class="colm">Category Name<span>:</span></label><span class="col-sm-4"> <?php echo $row["category"];?></span>
                                    </div>
                                	<div class="form-group">
                                    	<label class="colm"></label><span class="col-sm-4"></span>
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
      }
       if($action!="view"&&$action!="edit"&&$action!="delete"&&$action!="add")
  { 
      ?>
     
     
     
     
     
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Category</h4><a href="index.php?p=categories&action=add" class="btn btn-success">Add</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover data-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Category Name</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        
                                    
                                       $sql="select * from category";
                                      $sqlres=$obj_db->get_qresult($sql);

                                            $n=0;
                                        while($rows=$obj_db->fetchArray($sqlres))
                                                 {
                                                        $n++;
                                                   ?>
                                        <tr>
                                            <td><?php echo $n;?></td>
                                            <td><?php echo $rows["category"];?></td>
                                            <td class="action"><a href="index.php?p=categories&id=<?php echo $rows["id"];?>&action=view"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="index.php?p=categories&id=<?php echo $rows["id"];?>&action=edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="index.php?p=categories&id=<?php echo $rows["id"];?>&action=delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                              
                                             
                                            </tr>
                                      <?php
                                                 }
                                                 
                                                 ?>
                                        
                                    </tbody>
                                      
                                      
                                </table>
                                 
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
  }
  if($action=="add")
  {
  ?>
   <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Category Add</h4><a href="category.php" class="btn btn-success">back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form action="" method="POST">
                                	<div class="form-group">
                                    	<label class="colm">Category Name<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" name="category_name"/></span>
                                    </div>
                                	<div class="form-group">
                                    	<label class="colm"></label><span class="col-sm-4">
                                    	    <input type="submit" name="submit" value="submit" class="btn btn-success">
                                    	    
                                    	    </span>
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
  }
  ?>
    <!-- CONTENT-WRAPPER SECTION END-->
    
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATA TABLES SCRIPTS  -->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.min.js"></script>
    <script>
		$(document).ready(function() {
		$('#example').DataTable();
	} );
	</script>
</body>
</html>