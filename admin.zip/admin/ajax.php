<?php

include("DbConfig.php");

if(!empty($_POST['title'])){
	$val=$_POST['title'];
	echo $val;
	$state="";
	echo $state_qry="SELECT * from districts where stateid=".$val;
	$state_exe=$obj_db->get_qresult($state_qry);
	$state='<option value="">Select</option>';
	while($state_res=$obj_db->fetchArray($state_exe)){
	//echo '<pre>'; print_r($state_res); echo '</pre>';
		  $state.='<option value="'.$state_res['id'].'">'.$state_res['district'].'</option>';

		  
	
	}
	echo $state;

}


if(!empty($_POST['category'])){
	$val=$_POST['category'];
	echo $val;
	$state="";
	$state_qry="SELECT * from mandal where districtid=".$val;
	$state_exe=$obj_db->get_qresult($state_qry);
	$state='<option value="">Select</option>';
	while($state_res=$obj_db->fetchArray($state_exe)){
	//echo '<pre>'; print_r($state_res); echo '</pre>';
		  $state.='<option value="'.$state_res['id'].'">'.$state_res['mandals'].'</option>';
	
	}
	echo $state;

}

?>