<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.col-sm-4 input
{
	background-color:transparent !important;
	box-shadow:none;
	border:0px;	
}
.form-group
{
	margin-bottom:0px !important;
}
label
{
	margin-bottom:0px;
}
*
{
	line-height:25px;
}
.youtube
{
	padding-top:10px;
	font-size:30px;
	display:block;
	width:auto;
	color:red;
}
div.title
{
	width:100%;
	display:block;
}
div.title h3
{
	position:relative;
	color:#00bcd4;
}
div.title h3:before
{
	left:0px;
	width:100%;
	content:"";
	bottom:10px;
	position:absolute;
	border-bottom:2px solid #00bcd4;
}
div.title h3 span
{
	display:inline-block;
	padding-right:10px;
	position:relative;
	background:white;
	width:auto;
}
</style>
</head>

<body>
    
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Student View</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                           		<div class="col-sm-3">
                                	<div class="profile-pic">
                                    	<span class="prof-img"><img src="assets/img/avatar5.png" class="img-thumbnail" /></span>                                        
                                    </div>
                                </div>
                                <div class="col-sm-9">
                                    <h3>Student Info:</h3>
                                	<div class="col-sm-6">
                                        <span class="address">
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Name<span>:</span></label><span class="col-sm-4">John</span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Father Name<span>:</span></label><span class="col-sm-4">3rd</span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Mother Name<span>:</span></label><span class="col-sm-4">3rd</span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Date of Birth<span>:</span></label><span class="col-sm-4">15-08-2012</span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Address<span>:</span></label><span class="col-sm-4">8-2-29, Street Name, City Name, Pin Code.</span>
                                            </div>                                            
                                        </span>
                                    </div>
                                    <div class="col-sm-6">                                
                                        <form>
                                            <div class="form-group">
                                                <label class="colm">School Name<span>:</span></label><span class="col-sm-4">XXXX School</span>
                                            </div>
                                            <div class="form-group">
                                                <label class="colm">Class Studying<span>:</span></label><span class="col-sm-4">3rd</span>
                                            </div>
                                            <div class="form-group">
                                                <label class="colm">School Address<span>:</span></label><span class="col-sm-4">10-11-29, Street Name, City Name, Pin Code.</span>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                           </div> 
                           <div class="goodwill">
                           		<div class="col-sm-12"><a href="#" class="youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a></div>
                                <div class="col-sm-12">
                                	<div class="title"><h3><span>Contests</span></h3></div>
                                    <table class="table table-hover">
                                    	<thead>
                                        	<tr><th>Contest Name</th><th>Start Date</th><th>End Date</th><th>Likes</th><th>Dis-likes</th><th>Comments</th></tr>
                                        </thead>
                                        <tbody>
                                        	<tr><td>Singing</td><td>01-01-2019</td><td>05-01-2019</td><td>5</td><td>2</td><td>Good</td></tr>
                                        	<tr><td>Drawing</td><td>08-01-2019</td><td>09-01-2019</td><td>8</td><td>3</td><td>Good</td></tr>
                                        	<tr><td>Dancing</td><td>14-01-2019</td><td>16-01-2019</td><td>6</td><td>1</td><td>Good</td></tr>
                                        </tbody>
                                    </table>
                                </div>
                           </div>
                           
                            <div class="col-sm-12">                            
                              <div class="filter-group">	
                              <input type="search" class="light-table-filter form-control" data-table="order-table" placeholder="Filtrer" />                                                            
                              <select type="search" class="select-table-filter form-control" data-table="order-table">
                                <option value="">Reset</option>  
                                <option value="Doe">Doe</option>  
                                <option value="Vanda">Vanda</option>  
                              </select>                           
                              </div>
                                <table class="table table-hover order-table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>John Doe</td>
                                            <td>john.doe@gmail.com</td>
                                            <td>0123456789</td>
                                            <td>99</td>
                                        </tr>
                                        <tr>
                                            <td>Jane Vanda</td>
                                            <td>jane@vanda.org</td>
                                            <td>9876543210</td>
                                            <td>349</td>
                                        </tr>
                                        <tr>
                                            <td>Alferd Penyworth</td>
                                            <td>alfred@batman.com</td>
                                            <td>6754328901</td>
                                            <td>199</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/table-filter-index.js"></script>
</body>
</html>