<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<!-- DATA TABLES STYLE  -->
<link href="assets/css/dataTables.bootstrap.min.css" rel="stylesheet" />
</head>

<body>
    <?php if($action == "edit") {?>
     <div class="content-wrapper">
         <form action="" method="POST" enctype="multipart/form-data">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contest Edit</h4>
                    <a href="index.php?p=contests" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                      <div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                               <?php
                            $sql="select * from contests_add where id='".$_GET["id"]."'";
                            $sqlres=$obj_db->get_qresult($sql);
                                   while(
                                    $rows1=$obj_db->fetchArray($sqlres))

                                           {
                                           ?>
                                  <div class="form-group">
                                      <label class="colm">Title<span>:</span></label><span class="col-sm-8"><input type="text" name="Contest_Name"class="form-control" value="<?php echo $rows1["contest_name"];?>" /></span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Category<span>:</span></label><span class="col-sm-8">

                                            <select class="form-control" class="form-control" name="Category">
                              

                              <option value="">Select </option>

                              <?php
                               

                              $sql="select * from category";
                              $sqlres=$obj_db->get_qresult($sql);
                              while($rows=$obj_db->fetchArray($sqlres))
                              {
                                 ?>
                            <option value="<?php echo $rows["c_id"];?>" <?php if($rows1["category"]==$rows["c_id"]) echo "selected='selected'";?>><?php echo $rows["category"];?></option>
                              
                               <?php

                                  }
                                  ?>
                    
                            </select></span>
                                    </div>


                                  <div class="form-group">
                                      <label class="colm">Description<span>:</span></label><span class="col-sm-8"><textarea name="description"><?php echo $rows1["description"];?></textarea></span>                                        
                                    </div>
                                  <div class="form-group">
                                        <label class="colm">Start Date<span>:</span></label><span class="col-sm-8"><div 
                                        class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text"  name="Start_Date"  id="datepicker1" value="<?php if($rows1["start_date"]!='0000-00-00') { echo $newDate = date("d-m-Y", strtotime($rows1["start_date"]));} ?>"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                   

                           </div>
                                    <div class="form-group">
                                        <label class="colm">End Date<span>:</span></label><span class="col-sm-8"><div  
                                        class="input-group date" data-date-format="dd/mm/yyyy">
    

    <input class="form-control" type="text"  name="End_Date"  id="datepicker2" value="<?php if($rows1["end_date"]!='0000-00-00') { echo $newDate = date("d-m-Y", strtotime($rows1["end_date"]));} ?>"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>

                                    <div class="form-group">
                                      <label class="colm">Time Duration<span>:</span></label><span class="col-sm-8">

                                        <input type="text" name="Time_Duration" class="form-control" value="<?php echo $rows1["time_duration"];?>" />

                                        </span>                                        
                                    </div>
                                  <div class="form-group">
                                      <label class="colm">Price Amount<span>:</span></label><span class="col-sm-8"><input type="text" name="Prize_Amount" class="form-control" value="<?php echo $rows1["prize_amount"];?>" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                      <label class="colm">Audio File<span>:</span></label><span class="col-sm-8"> 

                                       <input name="audio" id="audio" type="file" value="<?php echo $_POST["audio"];?> "  />

                                       <audio controls>
                                                          <source src='audiofiles/<?php
                                                          $exp=explode('-',$rows1["audio_file"]);
                                             
                                             echo $exp[1];
                                                          
                                                          ?>' type='audio/mp3'>
  
                                                                </audio></span>                                        
                                    </div>



                                    
                                         <div class="form-group">
                                      <label class="colm">Video File<span>:</span></label><span class="col-sm-4">
                                        <input type="text" name="video_file" class="form-control" value="<?php echo $rows1["video_file"];?>" />
                                        
                                       <iframe width="560" height="315" src='<?php echo $rows1["video_file"];?>' frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>

                                      </span>                                    </div>


                                    <div class="form-group">
                                      <label class="colm">Status<span>:</span></label><span class="col-sm-8"> <input name="status" type="radio" id="signi" value="Active" <?php echo ($rows1["status"]== 'Active') ?  "checked" : "" ;  ?>/>Active
<input name="status" type="radio" id="signi" value="Inactive" <?php echo ($rows1["status"]== 'Inactive') ?  "checked" : "" ;  ?>/>Inactive</span>                                        
                                    </div>
                           
                            
 <?php
                             
                                      }
                               ?> 
                              
                            
                                  <div class="form-group">
                                      <label class="colm"></label><span class="col-sm-8">
                                          
                                          <input type="submit" value="submit" name="btn_press_save" class="btn btn-success">
                                      </span>                                        
                                    </div>
                                

                               
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        </form>
    </div>
    
     <?php }
      if($action == "view") {    
   ?>
   <div class="content-wrapper">
        <?php
      
$sql="select * from contests_add where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);
while(
$rows=$obj_db->fetchArray($sqlres))

{
    ?>
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contest View</h4><a href="index.php?p=contests" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                      <div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form action="" method="POST" enctype="multipart/form-data">
                                  <div class="form-group">
                                      <label class="colm">Title<span>:</span></label><span class="col-sm-4"><?php echo $rows["contest_name"];?></span></div>
                                  <div class="form-group">
                                      <label class="colm">Description<span>:</span></label><span class="col-sm-4"><?php echo $rows["description"];?></span>                                    </div>
                                  <div class="form-group">
                                      <label class="colm">Start Date<span>:</span></label><span class="col-sm-4"><?php echo 
                                      
                                      
                                      date("d-m-Y", strtotime($rows["start_date"]))
                                      
                                      ;?></span>                                    </div>
                                  <div class="form-group">
                                      <label class="colm">End Date<span>:</span></label><span class="col-sm-4"><?php echo date("d-m-Y", strtotime($rows["end_date"]));?></span>                                    </div>
                                  <div class="form-group">
                                      <label class="colm">Price Amount<span>:</span></label><span class="col-sm-4"><?php echo $rows["prize_amount"];?></span>                                    </div>

                                     <div class="form-group">
                                      <label class="colm">Audio File<span>:</span></label><span class="col-sm-4">




                                         <audio controls>
                                             <source src='audiofiles/<?php
                                            $exp=explode('-',$rows["audio_file"]);
                                             
                                             echo $exp[1];
                                             
                                             
                                              ?>' type='audio/mpeg'>
  
                                          </audio>

                                        
                                        </span> 
                                         </div>

                                         <div class="form-group">
                                      <label class="colm">Video File<span>:</span></label><span class="col-sm-4">
                                        
                                       <iframe width="560" height="315" src='<?php echo $rows["video_file"];?>' frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                                          

                                      </span>                                    </div>
<?php

}

?>
     
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
      }
      if($action!="view"&&$action!="edit"&&$action!="delete"&&$action!="add")
  { 
   ?>
   
    <!-- LOGO HEADER END-->
  
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contests</h4><a href="index.php?p=contests&action=add" class="btn btn-success">Add</a>
                   
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                      <div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover data-table">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Category</th>
                                            <th>Start Date</th>
                                            <th>End Date</th>
                                            <th>Prize Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                      <?php
                                        include("DbConfig.php");
            
                                         $sql="select * from contests_add";
                                        $sqlres=$obj_db->get_qresult($sql);
                                       
                                        while($rows=$obj_db->fetchArray($sqlres))
                                                  {
                                                    
                                        ?>
                                        <tr>
                                            
                                            <td><?php echo $rows["contest_name"];?></td>
                                            
                                             <td><?php 
                                             
                                             $sql4="select * from category where c_id='".$rows["category"]."'";
                                             
                                             $sqlres4=$obj_db->get_qresult($sql4);
                                             $row4=$obj_db->fetchRow($sql4);
                                             
                                             echo $row4["category"];?></td>
                                            <td><?php echo 
                                            date("d-m-Y", strtotime($rows["start_date"]))
                                            
                                            ;?></td>
                                            <td><?php echo
                                            date("d-m-Y", strtotime($rows["end_date"]));?></td>
                                            <td><?php echo $rows["prize_amount"];?></td>
                                            <td class="action"><a href="index.php?p=contests&id=<?php echo $rows["id"];?>&action=view"><i class="fa fa-eye" aria-hidden="true"></i></a> 
                                              <a href="index.php?p=contests&id=<?php echo $rows["id"];?>&action=edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> 
                                              <a href="index.php?p=contests&id=<?php echo $rows["id"];?>&action=delete"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                        </tr>
                                       
                                    </tbody>
                                     <?php

                                     }

                                      ?>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
  }if($action=="add")
  {
    ?>
     <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Contest Add</h4><a href="index.php?p=contests" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                        <div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form role="form" method="POST" enctype="multipart/form-data">
                                    <div class="form-group">
                                        <label class="colm">Category<span>:</span></label><span class="col-sm-8">

                                            <select class="form-control" class="form-control" name="Category">
                              

                              <option value="">Select </option>

                              <?php
                                include("DbConfig.php");

                              $sql="select * from category";
                              $sqlres=$obj_db->get_qresult($sql);
                              while($rows=$obj_db->fetchArray($sqlres))
                              {
                                 ?>
                            <option value="<?php echo $rows["c_id"];?>"><?php echo $rows["category"];?></option>
                              
                               <?php

                                  }
                                  ?>
                    
                            </select></span>
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Title<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Contest_Name"/></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Description<span>:</span></label><span class="col-sm-8"><textarea name="description">Next, use our Get Started docs to setup Tiny!</textarea></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Audio File<span>:</span></label><span class="col-sm-8">
                                            <input name="audio" id="audio" type="file" value="<?php echo $_POST["audio"];?> "  />
                                        </span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Video File(Embedded Code)<span>:</span></label><span class="col-sm-8">
                                            <input type="text" class="form-control" name="video_file" value="<?php echo $_POST["video_file"];?> "/> 
                                        </span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Status<span>:</span></label><span class="col-sm-8">
                                             Active <input type="radio" value="Active" name="name">
                                             Inactive <input type="radio" value="Inactive" name="name">
                                        </span>                                        
                                    </div>



                                    <div class="form-group">
                                        <label class="colm">Start Date<span>:</span></label><span class="col-sm-8"><div id="datepicker1" class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text"  id="datepicker1" name="Start_Date"/>
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">End Date<span>:</span></label><span class="col-sm-8"><div id="datepicker2" class="input-group date" data-date-format="dd/mm/yyyy">
    <input class="form-control" type="text" name="End_Date" id="datepicker2"  />
    <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
</div></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm">Time Duration<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Time_Duration"/></span>                                        
                                    </div>
                                    
                                    
                                    
                                    <div class="form-group">
                                        <label class="colm">Prize Amount<span>:</span></label><span class="col-sm-8"><input type="text" class="form-control" name="Prize_Amount"/></span>                                        
                                    </div>
                                    <div class="form-group">
                                        <label class="colm"></label><span class="col-sm-4">


                                            <input type="submit" value="Submit" name="submit" class="btn btn-success">
                                                                                   
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <?php
  }
  ?>

    <!-- CONTENT-WRAPPER SECTION END-->
   
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <!-- DATA TABLES SCRIPTS  -->
    <script src="assets/js/jquery.dataTables.min.js"></script>
    <script src="assets/js/dataTables.bootstrap.min.js"></script>
     <!-- TINYMCE SCRIPTS  -->
   
    <script>
    $(document).ready(function() {
    $('#example').DataTable();
  } );
  </script>
  
  <script>
  var $rows = $('#example tr');
$('#search').keyup(function() {
   var val = $.trim($(this).val()).replace(/ +/g, ' ').toLowerCase();
   
   $rows.show().filter(function() {
       var text = $(this).text().replace(/\s+/g, ' ').toLowerCase();
       return !~text.indexOf(val);
   }).hide();
});
  
  </script>
  
    <script src="https://cloud.tinymce.com/stable/tinymce.min.js"></script>
    <!-- DATE PICKER SCRIPTS  -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
    <script>tinymce.init({ selector:'textarea' });</script>
    <script>
    $(function() {
        
      $("#datepicker1").datepicker({ 
            autoclose: true, 
            format: 'dd-mm-yyyy',
            todayHighlight: true
      });
    
    
       $("#datepicker2").datepicker({ 
            autoclose: true, 
             format: 'dd-mm-yyyy',
            todayHighlight: true
      });
     
  
    
    });
    </script>
    
   
</body>
</html>

