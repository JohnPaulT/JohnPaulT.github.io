<?php 
session_start();
include("DbConfig.php");
if(!isset($_SESSION["username"]) )
{
  header("Location:login.php");

}

    ?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
<style>
.col-sm-4 input
{
	background-color:transparent !important;
	box-shadow:none;
	border:0px;	
}
.form-group
{
	margin-bottom:0px !important;
}
label
{
	margin-bottom:0px;
}
*
{
	line-height:25px;
}
.youtube
{
	padding-top:10px;
	font-size:30px;
	display:block;
	width:auto;
	color:red;
}
div.title
{
	width:100%;
	display:block;
}
div.title h3
{
	position:relative;
	color:#00bcd4;
}
div.title h3:before
{
	left:0px;
	width:100%;
	content:"";
	bottom:10px;
	position:absolute;
	border-bottom:2px solid #00bcd4;
}
div.title h3 span
{
	display:inline-block;
	padding-right:10px;
	position:relative;
	background:white;
	width:auto;
}
.outer{
       
       border:solid 1px #0a2444;
       width:500px;
       border-radius:10px;
       float:right;
       margin-bottom:20px;
       
   }

 .inner{
    
    border: none;
    width: 60%;
    background-color: #ea7f58;
    color: white;
    border-radius: 10px;
    padding-left: 10px;

   }
</style>
</head>

<body>
    
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
                <div class="outer"><div class="inner"><?php echo $total."%";?></div></div>
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Student View</h4>
                    <a href="students.php" class="btn btn-success">Back</a>
                   
                </div>
            </div>

                                <?php
                                $sql1="select * from registration where id='".$_GET["id"]."'";
                                $sqlres1=$obj_db->get_qresult($sql1);
                                $row1=$obj_db->fetchRow($sql1);
                                ?>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                           		<div class="col-sm-3">
                                	<div class="profile-pic">
                                    	<span class="prof-img"><img src="<?php echo $row1["imageg"];?>" class="img-thumbnail" /></span>                                     
                                    </div>
                                </div>
                               
                                <div class="col-sm-9">
                                    <h3>Student Info:</h3>
                                	<div class="col-sm-6">
                                        <span class="address">

                                             <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">AdhaarNumber<span>:</span></label><span class="col-sm-4">
                                                    <?php echo $row1["Aadhar_Number"];?>
                                                </span>
                                            </div>

                                             <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Title<span>:</span></label><span class="col-sm-4">
                                                    <?php echo $row1["Title"];?>
                                                </span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Name<span>:</span></label><span class="col-sm-4"><?php echo $row1["Name_of_Candidate"];?></span>
                                            </div>
                                             <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Gender<span>:</span></label><span class="col-sm-4">
                                                    <?php echo $row1["Gender"];?>
                                                </span>
                                            </div>
                                             

                                             <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Email<span>:</span></label><span class="col-sm-4">
                                                    <?php echo $row1["Email"];?>
                                                </span>
                                            </div>

                                            
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Father Name<span>:</span></label><span class="col-sm-4"><?php echo $row1["Father_Name"];?></span>
                                            </div>

                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Mother Name<span>:</span></label><span class="col-sm-4"><?php echo $row1["Mother_Name"];?></span>
                                            </div>



                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Mother Tongue<span>:</span></label><span class="col-sm-4">
                                                    <?php echo $row1["Mother_Tongue"];?>
                                                </span>
                                            </div>

                                            
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Date of Birth<span>:</span></label><span class="col-sm-4">
                                                    <?php echo
                                                    $date = date('m/d/Y', strtotime($row1["Date_of_Birth"]));
                                                   
                                                    ;?>
                                                </span>
                                            </div>
                                            <div class="form-group" style="margin-bottom:0px;">
                                                <label class="colm">Address<span>:</span></label><span class="col-sm-4"><?php
                                                  $sql2="select * from districts where stateid='".$row1["State"]."' and id='".$row1["District"]."'";
                                                  $sqlres2=$obj_db->get_qresult($sql2);
                                                  $row2=$obj_db->fetchRow($sql2);

                                                 echo $row1["House_Number"]."<br>,".$row1["Street"]."<br>,".$row1["City"]."<br>".$row1["districts"];

                                                 ?></span>
                                            </div>                                            
                                        </span>
                                    </div>
                                    
                                           
                                    
                                         
                                    <div class="col-sm-6">                                
                                        <!--<form>
                                            <div class="form-group">
                                                <label class="colm">School Name<span>:</span></label><span class="col-sm-4">XXXX School</span>
                                            </div>
                                            <div class="form-group">
                                                <label class="colm">Class Studying<span>:</span></label><span class="col-sm-4">3rd</span>
                                            </div>
                                            <div class="form-group">
                                                <label class="colm">School Address<span>:</span></label><span class="col-sm-4">10-11-29, Street Name, City Name, Pin Code.</span>
                                            </div>
                                        </form>-->
                                    </div>
                                </div>
                           </div> 
                           <div class="goodwill">
                           		<div class="col-sm-12"><a href="#" class="youtube"><i class="fa fa-youtube" aria-hidden="true"></i></a></div>
                                <div class="col-sm-12">
                                	<div class="title"><h3><span>Contests</span></h3></div>
                                    <table class="table table-hover">
                                    	<thead>
                                        	<tr><th>Contest Name</th><th>Start Date</th><th>End Date</th><th>Likes</th><th>Dis-likes</th><th>Comments</th></tr>
                                        </thead>
                                        <tbody>

                                            <?php
                                             $sql3="select * from contest_apply where s_id='".$_GET["id"]."'";
                                             $sqlres3=$obj_db->get_qresult($sql3);
                                             while($rows3=$obj_db->fetchArray($sqlres3))
                                             {
                                                ?>
                                        	<tr>
                                                <td>
                                                    <?php
                                                    $sql4="select * from contests_add where id='".$rows3["contest_id"]."'";
                                                    $sqlres4=$obj_db->get_qresult($sql4);
                                                    $row4=$obj_db->fetchRow($sql4);

                                                    echo $row4["contest_name"];

                                                  ?>


                                                </td>
                                                <td><?php echo $row4["start_date"];?></td>
                                                <td><?php echo $row4["end_date"];?></td>
                                                <td><?php echo $rows3["likes"];?></td>
                                                <td><?php echo $rows3["dislikes"];?></td>
                                                <td>Good</td>



                                            </tr>
                                        	<?php
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                           </div>
                           
                            <div class="col-sm-12">                            
                              <div class="filter-group">	
                              <input type="search" class="light-table-filter form-control" data-table="order-table" placeholder="Filtrer" />                                                            
                              <select type="search" class="select-table-filter form-control" data-table="order-table">
                                <option value="">Reset</option>  
                                <option value="Doe">Doe</option>  
                                <option value="Vanda">Vanda</option>  
                              </select>                           
                              </div>
                                <table class="table table-hover order-table">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Email</th>
                                            <th>Phone</th>
                                            <th>Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>John Doe</td>
                                            <td>john.doe@gmail.com</td>
                                            <td>0123456789</td>
                                            <td>99</td>
                                        </tr>
                                        <tr>
                                            <td>Jane Vanda</td>
                                            <td>jane@vanda.org</td>
                                            <td>9876543210</td>
                                            <td>349</td>
                                        </tr>
                                        <tr>
                                            <td>Alferd Penyworth</td>
                                            <td>alfred@batman.com</td>
                                            <td>6754328901</td>
                                            <td>199</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/table-filter-index.js"></script>
</body>
</html>