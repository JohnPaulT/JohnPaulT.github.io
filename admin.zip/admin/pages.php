<?php 

	
	

	switch($_GET['p']) 



	{           
                case "students" :  include("students.php"); break;
                case "teachers" :  include("teachers.php"); break;
                case "contests" :  include("contests.php"); break;
                  case "categories":include("category.php"); break;
               
	
default : include("inner.php"); break;
	}



?>