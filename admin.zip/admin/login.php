<?php
session_start();
include("DbConfig.php");

if(isset($_POST["submit"]))
{
$error=array();

if(empty($_POST["username"]))
{

  $error["username"]="please enter username";  
}
$sql="select * from adminlogin where username='".$_POST["username"]."'";
$sqlres=$obj_db->get_qresult($sql);
$row=$obj_db->fetchRow($sql);
if($_POST["username"]!=$row["username"])
{
   $error["username"]="Invalid username";  
}
if(empty($_POST["password"]))
{

  $error["password"]="please enter password";  
}
$sql1="select * from adminlogin where password='".$_POST["password"]."'";
$sqlres1=$obj_db->get_qresult($sql1);
$row1=$obj_db->fetchRow($sql1);

if($_POST["password"]!=$row1["password"])
{
   $error["password"]="Invalid password";  
}

$_SESSION["username"]=$row["username"];

if(count($error)==0)
{

   header("Location:index.php");
}
}
?>







<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <form action="" method="POST">
    <header>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <strong>Email: </strong>info@yourdomain.com
                    &nbsp;&nbsp;
                    <strong>Support: </strong>+90-897-678-44
                </div>

            </div>
        </div>
    </header>
    <!-- HEADER END-->
    <div class="navbar navbar-inverse set-radius-zero">
        <div class="container">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="index.php">

                    <img src="assets/img/logo.png" />
                </a>
            </div>            
            </div>
        </div>
    <!-- LOGO HEADER END-->
   
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <h4 class="page-head-line">Please Login To Enter </h4>

                </div>

            </div>
            <div class="row">
                <div class="login-box">
                    <br />
                     <label>Enter Username : </label>
                        <input type="text" class="form-control" name="username" value="<?php echo $_POST["username"];?>"/>
                        <div><?php echo $error["username"];?></div>
                        <label>Enter Password :  </label>
                        <input type="password" class="form-control" name="password"  value="<?php echo $_POST["password"];?>"/>
                        <div><?php echo $error["password"];?></div>
                        <hr />
                        <input type="submit" value="Log Me In" class="btn btn-info" name="submit">
                       
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <footer  class="footer">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p>&copy; 2019 <a href="#">Skillpundit</a>. All Rights Reserved.</p>
                </div>

            </div>
        </div>
    </footer>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
</form>
</body>
</html>
