<?php

	switch($_GET['p'])

	{
	
		case "students" :

			require_once("classes/class_students.php");
            $action = $_GET['action'];
            $id= $_GET['id'];

            $page_url_="index.php?p=students";

			$page_url="index.php?p=students";

			

			$page_url2="index.php?p=students";

			$obj_students = new students();

			

			if($id && $action=="delete"){					

				$obj_students->delete_students($id);						

			}

            




			
			if($action=="edit" && $id){				

					$dataC = $obj_students->get_student_details($id);

	

				 $data = $dataC;

				}	



			if($_POST) $data=$_POST;
			
		
			if(isset($_POST['btn_press_save'])) {
			    
             
			 $obj_students->student_edit($data,$id);
				
			}

			

       break;

       case "contests" :
       require_once("classes/class_contests.php");
            $action = $_GET['action'];
            $id= $_GET['id'];

            $page_url_="index.php?p=contests";

			$page_url="index.php?p=contests";

			

			$page_url2="index.php?p=contests";

			$obj_contests = new contests();

			

			if($id && $action=="delete"){					

				$obj_contests->delete_contests($id);						


			}

			if($action=="add") {				
                       
					
					$page_url2 .="&action=add";				

			}
         if($action=="edit" && $id){				

					$dataC = $obj_contests->get_contest_details($id);

	

				 $data = $dataC;

				}	



			if($_POST) $data=$_POST;
			
		
			if(isset($_POST['btn_press_save'])) {
			    
             
			 $obj_contests->contests_edit($data,$id);
				
			}
				if(isset($_POST['submit'])) {
			   
             
			 $obj_contests->contests_add($data);
				
			}

			

       break;

         case "categories" :
          require_once("classes/class_categories.php");
               $action = $_GET['action'];
            $id= $_GET['id'];

                  $page_url_="index.php?p=categories";

			$page_url="index.php?p=categories";

			

			$page_url2="index.php?p=categories";

			$obj_categories = new categories();

               if($id && $action=="delete"){					

				$obj_categories->delete_categories($id);						


			}

			if($action=="add") {				
                       
					
					$page_url2 .="&action=add";				

			}
         if($action=="edit" && $id){				

					$dataC = $obj_categories->get_categories_details($id);

	

				 $data = $dataC;

				}	



			if($_POST) $data=$_POST;
			
		
			if(isset($_POST['btn_press_save'])) {
			    
             
			 $obj_categories->categories_edit($data,$id);
				
			}
				if(isset($_POST['submit'])) {
			   
           
			$obj_categories->categories_add($data);
				
			}

			

       break;






}

?>