<?php 
session_start();
include("DbConfig.php");
if(!isset($_SESSION["username"]))
{
  header("Location:login.php");

}

if(isset($_POST["submit"]))
{
   $sql1="update registration set Aadhar_Number='".$_POST["Aadhar_Number"]."',Title='".$_POST["Title"]."',Gender='".$_POST["Gender"]."',Mother_Name='".$_POST["Mother_Name"]."',Father_Name='".$_POST["Father_Name"]."',Date_of_Birth='".$_POST["Date_of_Birth"]."',Mother_Tongue='".$_POST["Mother_Tongue"]."',Email='".$_POST["Email"]."',Contact_Number='".$_POST["Contact_Number"]."',House_Number='".$_POST["House_Number"]."',Street='".$_POST["Street"]."',City='".$_POST["City"]."',State='".$_POST["State"]."',District='".$_POST["District"]."' where id='".$_GET["id"]."'";


$sqlres1=$obj_db->get_qresult($sql1);


header("Location:students.php");

}


    ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />
<meta name="description" content="" />
<meta name="author" content="" />
<!--[if IE]>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <![endif]-->
<title>Skillpundit</title>
<link rel="shortcut icon" type="image/x-icon" href="assets/img/fav.png">
<!-- BOOTSTRAP CORE STYLE  -->
<link href="assets/css/bootstrap.css" rel="stylesheet" />
<!-- FONT AWESOME ICONS  -->
<link href="assets/css/font-awesome.css" rel="stylesheet" />
<!-- CUSTOM STYLE  -->
<link href="assets/css/style.css" rel="stylesheet" />
<!-- STICKY FOOTER STYLE  -->
<link href="assets/css/sticky-footer.css" rel="stylesheet" />
 <!-- HTML5 Shiv and Respond.js for IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    
    <!-- LOGO HEADER END-->
    <?php include "header.php" ?>
    <!-- MENU SECTION END-->
    <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Student Edit</h4>
                    <a href="students.php" class="btn btn-success">Back</a>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                           <div class="form-body">
                                <form action="" method="POST">

                                     <?php
                                     $sql="select * from registration where id='".$_GET["id"]."'";
                                     $sqlres=$obj_db->get_qresult($sql);
                                     $row=$obj_db->fetchRow($sql);
                                    // print_r($row);
                                     ?>

                                        <div class="form-group">
                                        <label class="colm">Adhaar Number<span>:</span></label><span class="col-sm-4"><input type="text" name="Aadhar_Number" class="form-control" value="<?php echo $row["Aadhar_Number"];?>" /></span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Title<span>:</span></label><span class="col-sm-4">

                                            <select class="form-control" name="Title" value="<?php echo $_POST["Title"];?> ">
                                         <option value="">Select</option>
                                         <option value="Mr" <?php if($row["Title"]=="Mr") echo 'selected="selected"'; ?>>Mr</option>
                                         <option value="Ms" <?php if($row["Title"]=="Ms") echo 'selected="selected"'; ?> >Ms</option>
                                          <option value="Mrs" <?php if($row["Title"]=="Mrs") echo 'selected="selected"'; ?>>Mrs</option>
                    
                                            </select>


                                        </span>                                        
                                    </div>


                                	<div class="form-group">
                                    	<label class="colm">First Name<span>:</span></label><span class="col-sm-4"><input type="text" name="first_name" class="form-control" value="<?php echo $row["first_name"];?>" /></span>                                        
                                    </div>
                                	<div class="form-group">
                                    	<label class="colm">Last Name<span>:</span></label><span class="col-sm-4"><input type="text" name="last_name" class="form-control" value="<?php echo $row["last_name"];?>" /></span>                                        
                                    </div>

                                     <div class="form-group">
                                        <label class="colm">Gender<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Gender"];?>" name="Gender" /></span>                                        
                                    </div>


                                	<div class="form-group">
                                    	<label class="colm">Father Name<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Father_Name"];?>" name="Father_Name" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Mother Name<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Mother_Name"];?>" name="Mother_Name" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Mother Tongue<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Mother_Tongue"];?>"  name="Mother_Tongue" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Date of Birth<span>:</span></label><span class="col-sm-4">


                                               <div id="datepicker1" class="input-group date" data-date-format="dd/mm/yyyy">
                                        <input class="form-control" type="text"  name="Date_of_Birth" value="<?php echo strftime('%m/%d/%Y', strtotime($row["Date_of_Birth"])); ?>"/>
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-calendar"></i></span>
                                            </div>


                                         
                                         </span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Contact Number<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Contact_Number"];?>" name="Contact_Number" /></span>                                        
                                    </div>



                                	
                                	<div class="form-group">
                                    	<label class="colm">Email Id<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Email"];?>" name="Email" /></span>                                        
                                    </div>

                                      <div class="form-group">
                                        <label class="colm">State<span>:</span></label><span class="col-sm-4">
                                            
                                           <select class="form-control" name="State" onChange="getDistrict(this.value);">
                                <option value="">Select</option>
                                    <?php $category_qry="SELECT * from states";
                                        $category_exe=$obj_db->get_qresult($category_qry);
                                           while($category=$obj_db->fetchArray($category_exe)){
                                            //echo '<pre>'; print_r($category); echo '</pre>';
                                    ?>
                                <option value="<?php echo $category['id'];?>" <?php if($category['id']==$row["State"]) echo 'selected="selected"'; ?>><?php echo $category['state']; ?></option>
                                 
                                    <?php }?>
                            </select>


                                        </span>                                        
                                    </div>

                                   <div class="form-group">
                                        <label class="colm">District<span>:</span></label><span class="col-sm-4">
                                            
                                           <select class="form-control" name="District" id="District" onChange="getMandal(this.value);">

                                <?php

                            $sql2="select * from districts where stateid='".$row["State"]."'";

                            $sqlres2=$obj_db->get_qresult($sql2);
                            while($categorydis=$obj_db->fetchArray($sqlres2))
                            {
                                  echo '<pre>'; print_r($category); echo '</pre>';
                                 
                            ?>

                                    <option value="<?php echo $categorydis['id'];?>" <?php if($categorydis['id']==$row["District"]) echo 'selected="selected"'; ?>><?php echo $categorydis['districts']; ?></option>
                                    <?php   }
                      ?>     
                                  </select>







                                        </span>                                        
                                    </div>








                               <div class="form-group">
                                        <label class="colm">House Number<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["House_Number"];?>" name="House_Number" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">Street<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["Street"];?>" name="Street" /></span>                                        
                                    </div>

                                    <div class="form-group">
                                        <label class="colm">City<span>:</span></label><span class="col-sm-4"><input type="text" class="form-control" value="<?php echo $row["City"];?>"  name="City" /></span>                                        
                                    </div>





                                	<div class="form-group">
                                    	<label class="colm"></label><span class="col-sm-4">


                                           <input type="submit" value="submit" name="submit" class="btn btn-success">

                                          
                                            </span>                                        
                                    </div>
                                </form>
                           </div> 
                        </div>
                    </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CONTENT-WRAPPER SECTION END-->
    <?php include "footer.php" ?>
    <!-- FOOTER SECTION END-->
    <!-- JAVASCRIPT AT THE BOTTOM TO REDUCE THE LOADING TIME  -->
    <!-- CORE JQUERY SCRIPTS -->
    <script src="assets/js/jquery-1.11.1.js"></script>
    <!-- BOOTSTRAP SCRIPTS  -->
    <script src="assets/js/bootstrap.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.3.0/js/bootstrap-datepicker.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
 <script type="text/javascript">
       $(function () {
  $("#datepicker").datepicker({ 
        autoclose: true, 
        todayHighlight: true
  })
});
    </script>

    

 <script>
 $("#husband").hide();
$('#maritalstatus').on('change', function () {
   
   if (this.value == 'UM') {
    $("#husband").hide();
    } 
   if (this.value == 'M') {
    $("#husband").show();
    }

   });
</script>
<script>
function function1(val){
 // alert(val);
  if(val == 'Mr'){
    document.getElementById('gender').value='Male';
  }
  if(val == 'Ms'){
    document.getElementById('gender').value='Female';
  }
  if(val == 'Mrs'){
    document.getElementById('gender').value='Female';
  }
}
</script>
<script>
function getAge(dateString) 
{
   
     var today = new Date();
   
    var birthDate = new Date(dateString);

    var age = today.getFullYear() - birthDate.getFullYear();
    var m = today.getMonth() - birthDate.getMonth();
  
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
       age = age - 1;
   }
 //alert(age);
   document.getElementById("age").value=age;
   
}
</script>

<script> 
function getDistrict(val) {
 //alert(val);
    $.ajax({
    type: "POST",
    url: "ajax.php",
    data:'title='+val, 
    success: function(data){
    $("#District").html(data);
    }
    });
    
}
function getMandal(val) {
 //alert(val);
    $.ajax({
    type: "POST",
    url: "ajax.php",
    data:'category='+val, 
    success: function(data){
    $("#Mandal").html(data);
    }
    });
    
}




</script>
<script>
    $(function () {
      $("#datepicker1").datepicker({ 
            autoclose: true, 
            todayHighlight: true
      });
      
      
      $("#datepicker2").datepicker({ 
            autoclose: true, 
            todayHighlight: true
      });
    
    });
    </script>
</body>
</html>












