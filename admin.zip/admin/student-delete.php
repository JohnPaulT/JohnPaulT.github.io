<?php
include("DbConfig.php");
$sql="delete from registration where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);
header("Location:students.php");

?>