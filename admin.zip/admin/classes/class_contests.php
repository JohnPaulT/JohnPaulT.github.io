<?php		
	
	class contests {	


	     function get_contest_details($id) {

			global $obj_db;

		$sql1="select * from contests_add where id='".$id."'";
			$sqlres1 = $obj_db->get_qresult($sql1);
		
			$row1=$obj_db->fetchRow($sql1);
			$user = $row1;			
			return $user;
		}


         function delete_contests($id) {

			global $obj_db, $page_url;
			  
			 $sql="delete from contests_add where id='".$id."'";
             $sqlres=$obj_db->get_qresult($sql);
		header("Location:index.php?p=contests");

		}
        

          function contests_edit($data, $id) {

                                          
                                                
                                               
			global $obj_db, $page_url;
			                       $startdate = date("Y-m-d", strtotime($data["Start_Date"]));
                                $enddate = date("Y-m-d", strtotime($data["End_Date"]));

                                $sql2="update contests_add set contest_name='".$data["Contest_Name"]."',category='".$data["Category"]."',prize_amount='".$data["Prize_Amount"]."',start_date='".$startdate."',end_date='".$enddate."',status='".$data["status"]."',description='".$data["description"]."',time_duration='".$data["Time_Duration"]."',video_file='".$data["video_file"]."' where id='".$id."'";
                                  
                                $sqlres2=$obj_db->get_qresult($sql2);

                                 
                                 $new_file_name=$_FILES['audio']['name'];
                                 $target_path = "audiofiles/".$new_file_name;
 
 
                            if(move_uploaded_file($_FILES['audio']['tmp_name'],"audiofiles/".$new_file_name))

                            {

                             $sql3="update contests_add set audio_file='$id-".$new_file_name."' where id='".$id."'";
                             
                                    $sqlres3=$obj_db->get_qresult($sql3);
                                     
                                    
                               }

                             




                           header("Location:index.php?p=contests");

                       }

                      




                       
				
		
		
              function contests_add($data) {

                                           
                                     global $obj_db, $page_url;     
                                             
                            $startdate = date("Y-m-d", strtotime($data["Start_Date"]));
                                $enddate = date("Y-m-d", strtotime($data["End_Date"]));

                             
    $sql4="insert into contests_add set contest_name='".$data["Contest_Name"]."',category='".$data["Category"]."',prize_amount='".$data["Prize_Amount"]."',start_date='".$startdate."',end_date='".$enddate."',status='".$data["name"]."',description='".$data["description"]."',time_duration='".$data["Time_Duration"]."',video_file='".$data["video_file"]."' ";
         $sqlres4=$obj_db->get_qresult($sql4);

                                 
                                   $new_file_name=$_FILES['audio']['name'];
                                 $target_path = "audiofiles/".$new_file_name;
 
 
                                   $sql1="select * from contests_add";
                                   $sqlres1=$obj_db->get_qresult($sql1);
                                   $last=$obj_db->insert_id($sql1);
                         
                             if(move_uploaded_file($_FILES['audio']['tmp_name'],"audiofiles/".$new_file_name)){
   $sql2="update contests_add set audio_file='$last-".$new_file_name."' where id='".$last."'";
   $sqlres2=$obj_db->get_qresult($sql2);

 
 $sql2="update contests_add set audio_file='$last-".$new_file_name."' where id='".$last."'";
   $sqlres2=$obj_db->get_qresult($sql2);
}

                                    
                               

                             




                           header("Location:index.php?p=contests");


                                    }




                                    

       }


	?>