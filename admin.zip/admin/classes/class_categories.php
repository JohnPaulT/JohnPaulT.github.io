<?php		
	
	class categories {	


	     function get_categories_details($id) {

			global $obj_db;

		$sql1="select * from category where id='".$id."'";
			$sqlres1 = $obj_db->get_qresult($sql1);
		
			$row1=$obj_db->fetchRow($sql1);
			$user = $row1;			
			return $user;
		}


         function delete_categories($id) {

			global $obj_db, $page_url;
			  
			 $sql="delete from category where id='".$id."'";
             $sqlres=$obj_db->get_qresult($sql);
		header("Location:index.php?p=categories");

		}
        

          function categories_edit($data, $id) {
                                   
			global $obj_db, $page_url;


			                      $sql="update category set category='".$data["category"]."' where id='".$id."'";
                                        $sqlres=$obj_db->get_qresult($sql);
                                       
                                        header("Location:index.php?p=categories"); 

                       }

                      




                       
				
		
		
              function categories_add($data) {

                                           
                                     global $obj_db, $page_url;     
                                         $sql="insert into category set category='".$data["category_name"]."'";
                                                $sqlres=$obj_db->get_qresult($sql);
                                                $last=$obj_db->insert_id($sql);
                                                
                                                $sql1="select * from category where id='".$last."'";
                                                $sqlres1=$obj_db->get_qresult($sql1);
                                                $row1=$obj_db->fetchRow($sql1);
                                                
                                                $sql2="update category set c_id='s".$row1["id"]."' where id='".$last."'";
                                                
                                                $sqlres2=$obj_db->get_qresult($sql2);
                                                
                                            header("Location:index.php?p=categories");     
                          
                                    }




                                    

       }


	?>