<?php		
	
	class students {	


	     function get_student_details($id) {

			global $obj_db;

		$sql1="select * from registration where id='".$id."'";
			$sqlres1 = $obj_db->get_qresult($sql1);
		
			$row1=$obj_db->fetchRow($sql1);
			$user = $row1;			
			return $user;
		}


         function delete_students($id) {

			global $obj_db, $page_url;
			  
			 $sql="delete from registration where id='".$id."'";
             $sqlres=$obj_db->get_qresult($sql);
			redirect_url($page_url);

		}
        function view_students($id) {

			global $obj_db, $page_url;
			  
			  $sql9="select * from registration where  id='".$id."'";

              $sqlres9=$obj_db->get_qresult($sql9);

              $row9=$obj_db->fetchRow($sql9);
              $total=$row9["statusbar"];
              return $row9;

			

		}

          function student_edit($data, $id) {
			global $obj_db, $page_url;
			         
							$sql2="update registration set Aadhar_Number='".$data['Aadhar_Number']."',Title='".$data['title']."',Gender='".$data['Gender']."',Mother_Name='".$data['Mother_Name']."',Father_Name='".$data['Father_Name']."',Date_of_Birth='".$data['Date_of_Birth']."',Mother_Tongue='".$data['Mother_Tongue']."',Email='".$data['Email']."',Contact_Number='".$data['Contact_Number']."',House_Number='".$data['House_Number']."',Street='".$data['Street']."',City='".$data['City']."',State='".$data['State']."',District='".$data['District']."' where id='".$id."'";



$sqlres2=$obj_db->get_qresult($sql2);

                           header("Location:index.php?p=students");
				
		}
		











	}

	?>