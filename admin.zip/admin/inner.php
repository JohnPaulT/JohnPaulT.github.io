<?php
?>

 <div class="content-wrapper">
        <div class="container">
            <div class="row">
                <div class="col-md-12 page-head-line">
                    <h4 class="page-head-title">Students Report</h4>
                </div>
            </div>
            <div class="row">
            	<div class="col-sm-12">
                	<div class="blocks">
                    	<div class="small-box bg-orange" style="background:#f0bb18 !IMPORTANT; margin-left:0px;">
                          <div class="inner">                          
                            <p><b>No. of Students</b></p>            
                              <h3 id="count_reg"> 268,949</h3>
                          </div>
                      	  <div class="icon"> <i class="fa fa-users"></i> </div>
                       </div>
                       <div class="small-box" style="background:#08aed7 !IMPORTANT;">
                          <div class="inner">
                           
                            <p> <b>Teachers</b></p>
                             <h3 id="count_reg"> 31,480   </h3>
                          </div>
                          <div class="icon"> <i class="fa fa-male" aria-hidden="true"></i> </div>
                      </div>
                      <div class="small-box" style="background:#95649e !IMPORTANT;">
                          <div class="inner">
                               
                                <p><b>Contests</b></p>
                                 <h3 id="count_present"> 2,923 </h3>
                          </div>
                          <div class="icon"> <i class="fa fa-gamepad" aria-hidden="true"></i> </div>
                      </div>
                      <div class="small-box" style="background:#9e8364 !IMPORTANT;">
                          <div class="inner">                            
                            <p><b>Reports</b></p>
                            <h3 id="count_device">1,851</h3>
                          </div>
          				 <div class="icon"> <i class="fa fa-flag" aria-hidden="true"></i> </div>
                      </div>
                      <div class="small-box" style="background:#1f9c83 !IMPORTANT;">
                          <div class="inner">                             
                            <p><b>Alerts</b></p>
                            <h3 id="count_device"> 1,212</h3>
                          </div>
                          <div class="icon"> <i class="fa fa-bell-o" aria-hidden="true"></i> </div>
                      </div>
                      <div class="small-box" style="background:#97ac67 !IMPORTANT;">
                          <div class="inner">                             
                            <p><b>Categories</b></p>
                            <h3 id="count_device"> 1,235</h3>
                          </div>
                          <div class="icon"> <i class="fa fa-sliders" aria-hidden="true"></i> </div>
          			</div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12 page-head-line" style="margin:40px 0px 20px;">
                    <h4 class="sub-title">Running contest traffic</h4>
                </div>
            </div>
            <div class="row">
                <div class="col-md-12">
                    <div>
                    	<div class="panel panel-default">
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table id="example" class="table table-hover data-table">
                                    <thead>
                                        <tr>
                                            <th>S.No</th>
                                            <th>Student Name</th>
                                            <th>Contest Name</th>
                                            <th>Youtube Link</th>
                                            <th>No. of Veiw</th>
                                            <th>No. of Comments</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>Teste</td>
                                            <td>Tester</td>
                                            <td><a href="https://www.youtube.com/watch?v=Fkd9TWUtFm0" target="_blank">https://www.youtube.com/watch?v=Fkd9TWUtFm0</a></td>
                                            <td>10,000</td>
                                            <td>500</td>
                                            <td class="action"><a href="student-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="student-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>
                                            </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>Test</td>
                                            <td>Tester</td>
                                            <td><a href="https://www.youtube.com/watch?v=Fkd9TWUtFm0" target="_blank">https://www.youtube.com/watch?v=Fkd9TWUtFm0</a></td>
                                            <td>9,000</td>
                                            <td>1,000</td>
                                            <td class="action"><a href="student-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="student-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                        <tr>
                                            <td>3</td>
                                            <td>Test2</td>
                                            <td>Tester2</td>
                                            <td><a href="https://www.youtube.com/watch?v=Fkd9TWUtFm0" target="_blank">https://www.youtube.com/watch?v=Fkd9TWUtFm0</a></td>
                                            <td>1,000</td>
                                            <td>1,000</td>
                                            <td class="action"><a href="student-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="student-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                        <tr>
                                            <td>4</td>
                                            <td>Test3</td>
                                            <td>Tester3</td>
                                            <td><a href="https://www.youtube.com/watch?v=Fkd9TWUtFm0" target="_blank">https://www.youtube.com/watch?v=Fkd9TWUtFm0</a></td>
                                            <td>5,000</td>
                                            <td>2,000</td>
                                            <td class="action"><a href="student-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="student-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                       </tr>
                                        <tr>
                                            <td>5</td>
                                            <td>Test4</td>
                                            <td>Tester4</td>
                                            <td><a href="https://www.youtube.com/watch?v=Fkd9TWUtFm0" target="_blank">https://www.youtube.com/watch?v=Fkd9TWUtFm0</a></td>
                                            <td>6,000</td>
                                            <td>1,200</td>
                                            <td class="action"><a href="student-view.php"><i class="fa fa-eye" aria-hidden="true"></i></a> <a href="student-edit.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a> <a href="#"><i class="fa fa-trash" aria-hidden="true"></i></a></td>                                   
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                    </div>
                </div>
            </div>            
        </div>
    </div>
  