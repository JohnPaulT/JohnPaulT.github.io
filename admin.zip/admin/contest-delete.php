<?php
session_start();
if(!isset($_SESSION["username"]))
{
    header('Location:login.php');
		exit();
    
    
}
include("DbConfig.php");

$sql="delete from contests_add where id='".$_GET["id"]."'";
$sqlres=$obj_db->get_qresult($sql);

header("Location:contests.php");
?>
